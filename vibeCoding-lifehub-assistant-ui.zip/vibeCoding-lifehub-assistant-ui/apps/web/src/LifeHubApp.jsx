import { useEffect, useMemo, useState } from 'react';

const STORAGE_KEYS = {
  books: 'lifehub-books-v3',
  workoutProfile: 'lifehub-workout-profile-v3',
  workoutEntries: 'lifehub-workout-entries-v3',
  memo: 'lifehub-memos-v3',
  schedules: 'lifehub-schedules-v3',
  trips: 'lifehub-trips-v3',
  transactions: 'lifehub-transactions-v3',
  budget: 'lifehub-budget-v1'
};

const NAV_ITEMS = [
  { label: '홈', path: '/home', icon: 'home' },
  { label: '메모', path: '/memo', icon: 'memo' },
  { label: '일정', path: '/schedule', icon: 'calendar' },
  { label: '더보기', path: '/more', icon: 'menu' }
];

const FEATURE_ITEMS = [
  { key: 'travel', title: '여행', subtitle: '다가오는 일정과 준비물', path: '/travel', icon: 'map', tone: 'green' },
  { key: 'finance', title: '가계부', subtitle: '이번 달 수입·지출 흐름', path: '/finance', icon: 'wallet', tone: 'blue' },
  { key: 'workout', title: '운동', subtitle: '오늘 운동과 누적 기록', path: '/workout', icon: 'trophy', tone: 'orange' },
  { key: 'reading', title: '독서', subtitle: '읽는 책과 다음 액션', path: '/reading', icon: 'book', tone: 'purple' }
];

const BOOK_STATUS = [
  { value: 'wish', label: '관심' },
  { value: 'reading', label: '읽는 중' },
  { value: 'done', label: '완독' }
];
const BOOK_STATUS_MAP = BOOK_STATUS.reduce((map, item) => ({ ...map, [item.value]: item.label }), {});

const WORKOUT_TABS = [
  { value: 'upper', label: '상체', icon: 'trophy', met: 5.0 },
  { value: 'lower', label: '하체', icon: 'spark', met: 5.5 },
  { value: 'cardio', label: '유산소', icon: 'runner', met: 7.0 }
];

const EXERCISE_PRESETS = {
  upper: [
    { name: '푸시업', sets: '3', reps: '12', weight: '' },
    { name: '덤벨 로우', sets: '3', reps: '10', weight: '8' }
  ],
  lower: [
    { name: '스쿼트', sets: '4', reps: '12', weight: '' },
    { name: '런지', sets: '3', reps: '10', weight: '' }
  ],
  cardio: [
    { name: '러닝', sets: '1', reps: '30', weight: '' },
    { name: '사이클', sets: '1', reps: '20', weight: '' }
  ]
};

const SCHEDULE_CATEGORIES = [
  { value: 'personal', label: '개인' },
  { value: 'work', label: '업무' },
  { value: 'health', label: '건강' },
  { value: 'workout', label: '운동' }
];

const FINANCE_CATEGORIES = ['식비', '교통', '쇼핑', '구독', '월급', '기타'];
const TRIP_STATUS = [
  { value: 'planned', label: '계획' },
  { value: 'booked', label: '예약' },
  { value: 'done', label: '완료' }
];

const ROUTE_META = {
  '/home': { title: '오늘의 비서', subtitle: '브리핑 · 할 일 · 빠른 기록', icon: 'spark' },
  '/memo': { title: '메모 비서', subtitle: '생각을 기록으로 정리', icon: 'memo', back: true, backTo: '/home' },
  '/schedule': { title: '일정 비서', subtitle: '오늘과 다음 계획 관리', icon: 'calendar', back: true, backTo: '/home' },
  '/more': { title: '관리 센터', subtitle: '생활 모듈과 루틴', icon: 'menu' },
  '/reading': { title: '독서 코치', subtitle: '책장과 진도 관리', icon: 'book', back: true },
  '/workout': { title: '운동 코치', subtitle: '세트 · 시간 · kcal', icon: 'trophy', back: true },
  '/travel': { title: '여행 컨시어지', subtitle: '일정 · 예약 · 준비물', icon: 'map', back: true },
  '/finance': { title: '재무 비서', subtitle: '월 예산과 입출금', icon: 'wallet', back: true }
};

function getTodayString() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function addDaysString(value, days) {
  const base = value ? new Date(`${value}T00:00:00`) : new Date();
  base.setDate(base.getDate() + days);
  const local = new Date(base.getTime() - base.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function normalizePath(path = '/') {
  const clean = path.split('?')[0] || '/';
  if (clean === '/') return '/home';
  return clean.replace(/\/+$/, '') || '/home';
}

function uid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // localStorage가 막힌 환경에서도 앱이 멈추지 않게 둡니다.
  }
}

function usePersistentState(key, fallback) {
  const [value, setValue] = useState(() => readStorage(key, fallback));
  useEffect(() => {
    writeStorage(key, value);
  }, [key, value]);
  return [value, setValue];
}

function formatDateKorean(value) {
  if (!value) return '-';
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('ko-KR', { month: 'long', day: 'numeric', weekday: 'short' }).format(date);
}

function formatDateCompact(value) {
  if (!value) return '-';
  const [year, month, day] = value.split('-');
  if (!year || !month || !day) return value;
  return `${month}.${day}`;
}

function formatCurrency(value) {
  return `${Number(value || 0).toLocaleString('ko-KR')}원`;
}

function currentMonthPrefix() {
  return getTodayString().slice(0, 7);
}

function getDaysBetween(start, end) {
  if (!start || !end) return 0;
  const startDate = new Date(`${start}T00:00:00`);
  const endDate = new Date(`${end}T00:00:00`);
  if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) return 0;
  return Math.max(1, Math.round((endDate - startDate) / 86400000) + 1);
}

function getDayDiff(target, base = getTodayString()) {
  if (!target) return null;
  const start = new Date(`${base}T00:00:00`);
  const end = new Date(`${target}T00:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return null;
  return Math.round((end - start) / 86400000);
}

function statusLabel(items, value) {
  return items.find((item) => item.value === value)?.label || value;
}

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, Number(value || 0)));
}

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 6) return '늦은 밤이에요';
  if (hour < 11) return '좋은 아침이에요';
  if (hour < 17) return '오후도 잘 챙겨볼게요';
  if (hour < 22) return '오늘 마무리할 시간이에요';
  return '하루를 정리해볼까요';
}

function getMonthTotals(transactions) {
  const month = currentMonthPrefix();
  const monthItems = transactions.filter((item) => item.date?.startsWith(month));
  const income = monthItems.filter((item) => item.type === 'income').reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const expense = monthItems.filter((item) => item.type !== 'income').reduce((sum, item) => sum + Number(item.amount || 0), 0);
  return { income, expense, balance: income - expense, count: monthItems.length, monthItems };
}

function getExpenseByCategory(transactions) {
  const { monthItems } = getMonthTotals(transactions);
  const rows = monthItems
    .filter((item) => item.type !== 'income')
    .reduce((map, item) => ({ ...map, [item.category]: (map[item.category] || 0) + Number(item.amount || 0) }), {});
  return Object.entries(rows).sort((a, b) => b[1] - a[1]);
}

function getProgress(book) {
  const total = Number(book.totalPages || 0);
  if (book.status === 'done') return 100;
  if (!total) return 0;
  return clamp(Math.round((Number(book.currentPage || 0) / total) * 100));
}

function parseQuickDate(text) {
  const today = getTodayString();
  if (/모레/.test(text)) return addDaysString(today, 2);
  if (/내일/.test(text)) return addDaysString(today, 1);
  if (/오늘/.test(text)) return today;
  return today;
}

function cleanQuickTitle(text) {
  return text.replace(/\b(오늘|내일|모레)\b/g, '').replace(/오늘|내일|모레/g, '').trim() || text.trim();
}

function Icon({ name, size = 22 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2.1, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true };
  switch (name) {
    case 'home': return <svg {...common}><path d="M3 11.5 12 4l9 7.5" /><path d="M5.5 10.5V20h13v-9.5" /><path d="M9.5 20v-5h5v5" /></svg>;
    case 'memo': return <svg {...common}><path d="M6 4h9l3 3v13H6z" /><path d="M14 4v4h4" /><path d="M9 12h6" /><path d="M9 16h4" /></svg>;
    case 'calendar': return <svg {...common}><rect x="4" y="5" width="16" height="15" rx="3" /><path d="M8 3v4" /><path d="M16 3v4" /><path d="M4 10h16" /></svg>;
    case 'menu': return <svg {...common}><path d="M5 7h14" /><path d="M5 12h14" /><path d="M5 17h14" /></svg>;
    case 'book': return <svg {...common}><path d="M5 5.5A3.5 3.5 0 0 1 8.5 2H20v17H8.5A3.5 3.5 0 0 0 5 22z" /><path d="M5 5.5v15" /><path d="M9 6h7" /><path d="M9 10h6" /></svg>;
    case 'trophy': return <svg {...common}><path d="M8 4h8v4a4 4 0 0 1-8 0z" /><path d="M8 6H5a3 3 0 0 0 3 3" /><path d="M16 6h3a3 3 0 0 1-3 3" /><path d="M12 12v4" /><path d="M9 20h6" /><path d="M10 16h4" /></svg>;
    case 'map': return <svg {...common}><path d="m9 18-5 2V6l5-2 6 2 5-2v14l-5 2z" /><path d="M9 4v14" /><path d="M15 6v14" /></svg>;
    case 'wallet': return <svg {...common}><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H19v14H6.5A2.5 2.5 0 0 1 4 16.5z" /><path d="M18 10h3v4h-3a2 2 0 0 1 0-4z" /><path d="M7 8h7" /></svg>;
    case 'back': return <svg {...common}><path d="M15 18 9 12l6-6" /></svg>;
    case 'arrow': return <svg {...common}><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></svg>;
    case 'spark': return <svg {...common}><path d="M12 2l1.9 6.1L20 10l-6.1 1.9L12 18l-1.9-6.1L4 10l6.1-1.9z" /><path d="M19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8z" /></svg>;
    case 'runner': return <svg {...common}><path d="M13 4.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" /><path d="m6 21 3-5" /><path d="m17 21-2.5-5-3.5-2 2-4" /><path d="m8 10 3-3 3 1 3 3" /><path d="M4 13h4" /></svg>;
    case 'trash': return <svg {...common}><path d="M4 7h16" /><path d="M10 11v6" /><path d="M14 11v6" /><path d="M6 7l1 14h10l1-14" /><path d="M9 7V4h6v3" /></svg>;
    case 'plus': return <svg {...common}><path d="M12 5v14" /><path d="M5 12h14" /></svg>;
    case 'check': return <svg {...common}><path d="m5 12 4 4L19 6" /></svg>;
    case 'search': return <svg {...common}><circle cx="11" cy="11" r="7" /><path d="m16.5 16.5 3.5 3.5" /></svg>;
    case 'pin': return <svg {...common}><path d="m14 4 6 6" /><path d="m13 5-7 7 6 6 7-7" /><path d="m7 17-3 3" /></svg>;
    case 'bell': return <svg {...common}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></svg>;
    case 'clock': return <svg {...common}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>;
    case 'target': return <svg {...common}><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4" /><path d="M12 2v3" /><path d="M12 19v3" /><path d="M2 12h3" /><path d="M19 12h3" /></svg>;
    case 'trend': return <svg {...common}><path d="m4 16 5-5 4 4 7-8" /><path d="M15 7h5v5" /></svg>;
    case 'chat': return <svg {...common}><path d="M21 12a8 8 0 0 1-8 8H6l-3 3v-7a8 8 0 1 1 18-4z" /><path d="M8 10h8" /><path d="M8 14h5" /></svg>;
    case 'shield': return <svg {...common}><path d="M12 3 20 7v5c0 5-3.4 8-8 9-4.6-1-8-4-8-9V7z" /><path d="m9 12 2 2 4-5" /></svg>;
    case 'coffee': return <svg {...common}><path d="M5 8h12v5a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5z" /><path d="M17 9h1a3 3 0 0 1 0 6h-1" /><path d="M7 3v2" /><path d="M11 3v2" /><path d="M15 3v2" /></svg>;
    case 'moon': return <svg {...common}><path d="M21 13.2A8.5 8.5 0 0 1 10.8 3a7 7 0 1 0 10.2 10.2z" /></svg>;
    case 'zap': return <svg {...common}><path d="m13 2-8 12h7l-1 8 8-12h-7z" /></svg>;
    default: return <svg {...common}><circle cx="12" cy="12" r="9" /></svg>;
  }
}

function AppHeader({ route, navigate, briefingCount }) {
  const meta = ROUTE_META[route] || ROUTE_META['/home'];
  const canGoBack = meta.back;
  return (
    <header className="paHeader">
      <div className="paHeaderLeft">
        <button type="button" className="paIconButton" onClick={() => (canGoBack ? navigate(meta.backTo || '/more') : navigate('/home'))} aria-label={canGoBack ? '뒤로가기' : '홈'}>
          <Icon name={canGoBack ? 'back' : meta.icon} size={22} />
        </button>
        <div className="paTitleBlock">
          <strong>{meta.title}</strong>
          <span>{meta.subtitle}</span>
        </div>
      </div>
      <button type="button" className="paAssistantPill" onClick={() => navigate('/home')} aria-label="오늘의 비서 홈으로 이동">
        <span className="paAvatar"><Icon name="spark" size={18} /></span>
        <span><strong>비서 ON</strong><em>{briefingCount}개 브리핑</em></span>
      </button>
    </header>
  );
}

function BottomNav({ route, navigate }) {
  const activePath = ['/reading', '/workout', '/travel', '/finance'].includes(route) ? '/more' : route;
  return (
    <nav className="paBottomNav" aria-label="하단 메뉴">
      {NAV_ITEMS.map((item) => (
        <button type="button" key={item.path} className={activePath === item.path ? 'active' : ''} onClick={() => navigate(item.path)}>
          <Icon name={item.icon} size={20} />
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

function SectionCard({ children, className = '' }) {
  return <section className={`paCard ${className}`}>{children}</section>;
}

function SectionTitle({ eyebrow, title, value, children }) {
  return (
    <div className="paSectionTitle">
      <div>
        {eyebrow ? <span>{eyebrow}</span> : null}
        <h2>{title}</h2>
      </div>
      {children || (value ? <strong>{value}</strong> : null)}
    </div>
  );
}

function MetricTile({ label, value, hint, icon = 'spark', tone = 'mint' }) {
  return (
    <article className={`paMetric ${tone}`}>
      <span className="paMetricIcon"><Icon name={icon} size={18} /></span>
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
        {hint ? <em>{hint}</em> : null}
      </div>
    </article>
  );
}

function MiniProgress({ value }) {
  return <span className="paProgress"><i style={{ width: `${clamp(value)}%` }} /></span>;
}

function EmptyState({ title, children, icon = 'spark' }) {
  return <div className="paEmptyState"><Icon name={icon} size={24} /><strong>{title}</strong>{children ? <span>{children}</span> : null}</div>;
}

function QuickCapture({ setMemos, setSchedules, compact = false }) {
  const [mode, setMode] = useState('schedule');
  const [text, setText] = useState('');
  const [saved, setSaved] = useState('');

  const save = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    if (mode === 'memo') {
      setMemos((items) => [{ id: uid(), text: trimmed, tag: '비서', pinned: false, createdAt: new Date().toISOString() }, ...items]);
      setSaved('메모로 저장했어요');
    } else {
      const date = parseQuickDate(trimmed);
      setSchedules((items) => [{ id: uid(), title: cleanQuickTitle(trimmed), date, time: '', category: 'personal', memo: '빠른 입력으로 추가됨', done: false, createdAt: new Date().toISOString() }, ...items]);
      setSaved(`${formatDateCompact(date)} 일정으로 넣었어요`);
    }
    setText('');
    window.setTimeout(() => setSaved(''), 1800);
  };

  return (
    <SectionCard className={`paCommandCard ${compact ? 'compact' : ''}`}>
      <div className="paCommandHead">
        <span className="paBotMark"><Icon name="chat" size={19} /></span>
        <div><strong>비서에게 맡기기</strong><em>짧게 적으면 기록으로 정리해둘게요.</em></div>
      </div>
      <div className="paSegmented mini" role="tablist" aria-label="빠른 입력 유형">
        <button type="button" className={mode === 'schedule' ? 'active' : ''} onClick={() => setMode('schedule')}>할 일</button>
        <button type="button" className={mode === 'memo' ? 'active' : ''} onClick={() => setMode('memo')}>메모</button>
      </div>
      <div className="paCommandInput">
        <input value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') save(); }} placeholder={mode === 'schedule' ? '예: 내일 병원 예약 확인' : '예: 다음 프로젝트 아이디어'} />
        <button type="button" onClick={save} disabled={!text.trim()}><Icon name="arrow" size={18} /></button>
      </div>
      {saved ? <p className="paSaveToast"><Icon name="check" size={15} />{saved}</p> : null}
    </SectionCard>
  );
}

function buildAssistantBriefing({ books, workoutEntries, memos, schedules, trips, transactions, profile, budget }) {
  const today = getTodayString();
  const todaySchedules = schedules.filter((item) => item.date === today && !item.done).sort((a, b) => `${a.time || '99:99'}`.localeCompare(`${b.time || '99:99'}`));
  const overdue = schedules.filter((item) => item.date < today && !item.done).sort((a, b) => a.date.localeCompare(b.date));
  const upcoming = schedules.filter((item) => item.date > today && !item.done).sort((a, b) => `${a.date} ${a.time || '99:99'}`.localeCompare(`${b.date} ${b.time || '99:99'}`));
  const todayWorkout = workoutEntries.some((entry) => entry.date === today);
  const readingNow = books.filter((book) => book.status === 'reading').sort((a, b) => getProgress(a) - getProgress(b));
  const finance = getMonthTotals(transactions);
  const nextTrip = trips.filter((trip) => trip.startDate >= today && trip.status !== 'done').sort((a, b) => a.startDate.localeCompare(b.startDate))[0];
  const pinnedMemos = memos.filter((memo) => memo.pinned);
  const monthlyBudget = Number(budget?.monthly || 0);
  const items = [];

  if (overdue.length) {
    items.push({ id: 'overdue', title: `놓친 일정 ${overdue.length}개`, body: `${overdue[0].title}부터 정리하면 좋아요.`, icon: 'bell', tone: 'danger', path: '/schedule', actionLabel: '정리하기' });
  } else if (todaySchedules.length) {
    items.push({ id: 'today', title: `오늘 일정 ${todaySchedules.length}개`, body: `${todaySchedules[0].time || '종일'} · ${todaySchedules[0].title}`, icon: 'calendar', tone: 'mint', path: '/schedule', actionLabel: '오늘 보기' });
  } else if (upcoming.length) {
    items.push({ id: 'next', title: '오늘은 여유 있어요', body: `다음 일정은 ${formatDateCompact(upcoming[0].date)} ${upcoming[0].title}입니다.`, icon: 'coffee', tone: 'blue', path: '/schedule', actionLabel: '일정 보기' });
  } else {
    items.push({ id: 'empty-day', title: '오늘 일정이 비어 있어요', body: '해야 할 일을 하나만 넣어도 하루 흐름이 잡혀요.', icon: 'target', tone: 'mint', path: '/schedule', actionLabel: '추가하기' });
  }

  if (!todayWorkout) {
    const missingProfile = !Number(profile?.weight) || !Number(profile?.height);
    items.push({ id: 'workout', title: missingProfile ? '운동 계산 세팅 필요' : '오늘 운동 미기록', body: missingProfile ? '몸무게와 키를 넣으면 kcal가 자동 계산돼요.' : '짧게 20분만 기록해도 루틴이 이어집니다.', icon: 'trophy', tone: 'orange', path: '/workout', actionLabel: missingProfile ? '정보 입력' : '기록하기' });
  } else {
    const todayEntry = workoutEntries.find((entry) => entry.date === today);
    items.push({ id: 'workout-done', title: '오늘 운동 완료', body: `${todayEntry.label} ${todayEntry.minutes || 0}분 · ${todayEntry.kcal || 0} kcal`, icon: 'shield', tone: 'green', path: '/workout', actionLabel: '기록 보기' });
  }

  if (readingNow.length) {
    items.push({ id: 'reading', title: '읽던 책 이어가기', body: `${readingNow[0].title} · ${getProgress(readingNow[0])}% 진행`, icon: 'book', tone: 'purple', path: '/reading', actionLabel: '책장 보기' });
  } else if (books.length) {
    items.push({ id: 'reading-wish', title: '다음 책을 고를 시간', body: `관심 책 ${books.filter((book) => book.status === 'wish').length}권 중 하나를 읽는 중으로 바꿔보세요.`, icon: 'book', tone: 'purple', path: '/reading', actionLabel: '선택하기' });
  }

  if (nextTrip) {
    const diff = getDayDiff(nextTrip.startDate);
    items.push({ id: 'trip', title: diff === 0 ? '오늘 여행 출발' : `여행 D-${Math.max(0, diff)}`, body: `${nextTrip.title} · ${nextTrip.destination || '목적지 미정'}`, icon: 'map', tone: 'green', path: '/travel', actionLabel: '준비물 확인' });
  }

  if (monthlyBudget && finance.expense >= monthlyBudget * 0.8) {
    items.push({ id: 'budget', title: '예산 80% 이상 사용', body: `이번 달 지출 ${formatCurrency(finance.expense)} / 예산 ${formatCurrency(monthlyBudget)}`, icon: 'wallet', tone: 'danger', path: '/finance', actionLabel: '지출 보기' });
  } else if (finance.count) {
    items.push({ id: 'finance', title: '이번 달 현금 흐름', body: `잔액 ${formatCurrency(finance.balance)} · 기록 ${finance.count}건`, icon: 'trend', tone: 'blue', path: '/finance', actionLabel: '가계부 보기' });
  }

  if (pinnedMemos.length) {
    items.push({ id: 'memo', title: `고정 메모 ${pinnedMemos.length}개`, body: pinnedMemos[0].text, icon: 'pin', tone: 'mint', path: '/memo', actionLabel: '메모 보기' });
  }

  return items.slice(0, 6);
}

function AssistantBriefing({ items, navigate }) {
  return (
    <SectionCard className="paBriefingCard">
      <SectionTitle eyebrow="Assistant briefing" title="지금 확인할 것" value={`${items.length}개`} />
      <div className="paBriefingList">
        {items.map((item) => (
          <button type="button" className={`paBriefingItem ${item.tone}`} key={item.id} onClick={() => navigate(item.path)}>
            <span className="paBriefIcon"><Icon name={item.icon} size={19} /></span>
            <span className="paBriefText"><strong>{item.title}</strong><em>{item.body}</em></span>
            <span className="paBriefAction">{item.actionLabel}</span>
          </button>
        ))}
      </div>
    </SectionCard>
  );
}

function HomePage({ data, setters, briefing, navigate }) {
  const { books, workoutEntries, memos, schedules, trips, transactions } = data;
  const { setMemos, setSchedules } = setters;
  const today = getTodayString();
  const todaySchedules = schedules.filter((item) => item.date === today && !item.done).sort((a, b) => `${a.time || '99:99'}`.localeCompare(`${b.time || '99:99'}`));
  const overdue = schedules.filter((item) => item.date < today && !item.done).length;
  const workoutMinutes = workoutEntries.filter((entry) => entry.date === today).reduce((sum, entry) => sum + Number(entry.minutes || 0), 0);
  const readingCount = books.filter((book) => book.status === 'reading').length;
  const finance = getMonthTotals(transactions);
  const nextTrip = trips.filter((trip) => trip.startDate >= today && trip.status !== 'done').sort((a, b) => a.startDate.localeCompare(b.startDate))[0];
  const nextSchedule = todaySchedules[0];
  const completion = todaySchedules.length ? Math.round((schedules.filter((item) => item.date === today && item.done).length / schedules.filter((item) => item.date === today).length) * 100) : 0;

  const toggleSchedule = (id) => {
    setSchedules((items) => items.map((item) => item.id === id ? { ...item, done: !item.done } : item));
  };

  return (
    <main className="paContent">
      <section className="paHero">
        <div className="paHeroGlow" />
        <div className="paHeroTop">
          <span>{formatDateKorean(today)}</span>
          <b>Personal Assistant</b>
        </div>
        <h1>{getGreeting()}<br />오늘은 제가 정리해둘게요.</h1>
        <p>{nextSchedule ? `${nextSchedule.time || '종일'}에 '${nextSchedule.title}'부터 챙기면 됩니다.` : overdue ? `놓친 일정 ${overdue}개가 있어 먼저 정리하면 좋아요.` : '급한 일정은 없어요. 기록 하나만 남겨도 흐름이 좋아집니다.'}</p>
        <div className="paHeroActions">
          <button type="button" onClick={() => navigate('/schedule')}>오늘 일정</button>
          <button type="button" onClick={() => navigate('/memo')}>메모 정리</button>
        </div>
      </section>

      <div className="paMetricGrid four">
        <MetricTile label="오늘 일정" value={`${todaySchedules.length}개`} hint={overdue ? `놓침 ${overdue}개` : `${completion}% 완료`} icon="calendar" tone="mint" />
        <MetricTile label="오늘 운동" value={`${workoutMinutes}분`} hint="기록 기준" icon="trophy" tone="orange" />
        <MetricTile label="읽는 책" value={`${readingCount}권`} hint={`${books.filter((book) => book.status === 'done').length}권 완독`} icon="book" tone="purple" />
        <MetricTile label="이번 달" value={formatCurrency(finance.balance)} hint={`${finance.count}건 기록`} icon="wallet" tone="blue" />
      </div>

      <AssistantBriefing items={briefing} navigate={navigate} />
      <QuickCapture setMemos={setMemos} setSchedules={setSchedules} />

      <SectionCard>
        <SectionTitle eyebrow="Today agenda" title="오늘 일정 타임라인" value={`${todaySchedules.length}개`} />
        {todaySchedules.length ? (
          <div className="paTimeline">
            {todaySchedules.slice(0, 5).map((item) => (
              <article className="paTimelineItem" key={item.id}>
                <button type="button" className="paCheck" onClick={() => toggleSchedule(item.id)} aria-label="완료"><Icon name="check" size={15} /></button>
                <time>{item.time || '종일'}</time>
                <div><strong>{item.title}</strong><span>{statusLabel(SCHEDULE_CATEGORIES, item.category || 'personal')}{item.memo ? ` · ${item.memo}` : ''}</span></div>
              </article>
            ))}
          </div>
        ) : <EmptyState title="오늘 일정이 없습니다" icon="calendar">비서 입력창에 “내일 회의 준비”처럼 적어보세요.</EmptyState>}
      </SectionCard>

      <SectionCard>
        <SectionTitle eyebrow="Quick modules" title="자주 쓰는 관리" />
        <div className="paShortcutGrid">
          {FEATURE_ITEMS.map((feature) => (
            <button type="button" className={`paShortcut ${feature.tone}`} key={feature.key} onClick={() => navigate(feature.path)}>
              <span><Icon name={feature.icon} size={20} /></span>
              <strong>{feature.title}</strong>
              <em>{feature.subtitle}</em>
            </button>
          ))}
        </div>
      </SectionCard>

      {nextTrip ? (
        <button type="button" className="paNextTrip" onClick={() => navigate('/travel')}>
          <span><Icon name="map" size={20} /></span>
          <div><strong>{nextTrip.title}</strong><em>{formatDateCompact(nextTrip.startDate)} 출발 · {nextTrip.destination || '목적지 미정'}</em></div>
          <b>D-{Math.max(0, getDayDiff(nextTrip.startDate) || 0)}</b>
        </button>
      ) : null}
    </main>
  );
}

function MorePage({ data, setters, navigate }) {
  const { books, workoutEntries, trips, transactions } = data;
  const { setSchedules, setMemos } = setters;
  const finance = getMonthTotals(transactions);
  const enhancedFeatures = FEATURE_ITEMS.map((feature) => {
    if (feature.key === 'reading') return { ...feature, metric: `${books.length}권 등록` };
    if (feature.key === 'workout') return { ...feature, metric: `${new Set(workoutEntries.map((entry) => entry.date)).size}일 운동` };
    if (feature.key === 'travel') return { ...feature, metric: `${trips.filter((trip) => trip.startDate >= getTodayString() && trip.status !== 'done').length}개 예정` };
    if (feature.key === 'finance') return { ...feature, metric: `${formatCurrency(finance.balance)} 잔액` };
    return feature;
  });

  const addRoutine = (type) => {
    if (type === 'morning') {
      setSchedules((items) => [
        { id: uid(), title: '오늘 우선순위 3개 정리', date: getTodayString(), time: '09:00', category: 'work', memo: '아침 루틴', done: false, createdAt: new Date().toISOString() },
        { id: uid(), title: '가계부 전날 지출 확인', date: getTodayString(), time: '09:10', category: 'personal', memo: '아침 루틴', done: false, createdAt: new Date().toISOString() },
        ...items
      ]);
    } else if (type === 'night') {
      setSchedules((items) => [{ id: uid(), title: '하루 기록 정리', date: getTodayString(), time: '22:30', category: 'personal', memo: '저녁 루틴', done: false, createdAt: new Date().toISOString() }, ...items]);
    } else {
      setMemos((items) => [{ id: uid(), text: '이번 주 점검: 일정, 지출, 운동, 독서 기록을 한 번씩 확인하기', tag: '루틴', pinned: true, createdAt: new Date().toISOString() }, ...items]);
    }
  };

  return (
    <main className="paContent">
      <section className="paControlHero">
        <span className="paKicker">Command center</span>
        <h1>개인비서처럼 생활 모듈을 한곳에서 관리해요.</h1>
        <p>앱을 들어왔을 때 “뭘 해야 하지?”가 아니라 “이것부터 하면 된다”가 보이도록 정리했습니다.</p>
      </section>

      <div className="paModuleGrid">
        {enhancedFeatures.map((feature) => (
          <button type="button" className={`paModuleCard ${feature.tone}`} key={feature.key} onClick={() => navigate(feature.path)}>
            <span><Icon name={feature.icon} size={22} /></span>
            <div><strong>{feature.title}</strong><em>{feature.subtitle}</em><small>{feature.metric}</small></div>
            <Icon name="arrow" size={18} />
          </button>
        ))}
      </div>

      <SectionCard>
        <SectionTitle eyebrow="Assistant routines" title="비서 루틴 빠른 등록" />
        <div className="paRoutineGrid">
          <button type="button" onClick={() => addRoutine('morning')}><Icon name="coffee" size={18} /><strong>아침 브리핑</strong><span>우선순위와 지출 확인</span></button>
          <button type="button" onClick={() => addRoutine('night')}><Icon name="moon" size={18} /><strong>저녁 정리</strong><span>하루 기록 마감</span></button>
          <button type="button" onClick={() => addRoutine('weekly')}><Icon name="target" size={18} /><strong>주간 점검</strong><span>고정 메모로 저장</span></button>
        </div>
      </SectionCard>

      <QuickCapture setMemos={setMemos} setSchedules={setSchedules} compact />
    </main>
  );
}

function ReadingPage({ books, setBooks }) {
  const [filter, setFilter] = useState('all');
  const [form, setForm] = useState({ title: '', author: '', status: 'wish', memo: '', currentPage: '', totalPages: '', rating: '' });
  const counts = useMemo(() => ({
    wish: books.filter((book) => book.status === 'wish').length,
    reading: books.filter((book) => book.status === 'reading').length,
    done: books.filter((book) => book.status === 'done').length
  }), [books]);
  const filteredBooks = filter === 'all' ? books : books.filter((book) => book.status === filter);
  const readingNow = books.filter((book) => book.status === 'reading').sort((a, b) => getProgress(a) - getProgress(b))[0];
  const average = books.length ? Math.round(books.reduce((sum, book) => sum + getProgress(book), 0) / books.length) : 0;

  const addBook = (event) => {
    event.preventDefault();
    if (!form.title.trim()) return;
    setBooks([{ id: uid(), createdAt: new Date().toISOString(), ...form, title: form.title.trim(), author: form.author.trim(), memo: form.memo.trim() }, ...books]);
    setForm({ title: '', author: '', status: 'wish', memo: '', currentPage: '', totalPages: '', rating: '' });
  };
  const updateBook = (id, patch) => setBooks(books.map((book) => (book.id === id ? { ...book, ...patch } : book)));

  return (
    <main className="paContent">
      <section className="paCoachHero purple">
        <span><Icon name="book" size={21} /> 독서 코치</span>
        <h1>{readingNow ? `다음은 ${readingNow.title} 이어 읽기` : '책장을 먼저 채워볼까요?'}</h1>
        <p>{readingNow ? `${getProgress(readingNow)}% 진행 중이에요. 현재 페이지를 업데이트하면 진도가 바로 반영됩니다.` : '관심 책, 읽는 책, 완독 책을 분리해서 관리합니다.'}</p>
      </section>

      <div className="paMetricGrid four">
        <MetricTile label="관심" value={`${counts.wish}권`} icon="book" tone="mint" />
        <MetricTile label="읽는 중" value={`${counts.reading}권`} icon="target" tone="purple" />
        <MetricTile label="완독" value={`${counts.done}권`} icon="check" tone="blue" />
        <MetricTile label="평균 진도" value={`${average}%`} icon="trend" tone="orange" />
      </div>

      <SectionCard>
        <SectionTitle eyebrow="Book capture" title="책 추가" value={`${books.length}권`} />
        <form className="paForm" onSubmit={addBook}>
          <label className="paField full"><span>책 제목</span><input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="예: 세이노의 가르침" /></label>
          <label className="paField"><span>작가</span><input value={form.author} onChange={(event) => setForm({ ...form, author: event.target.value })} placeholder="작가명" /></label>
          <label className="paField"><span>별점</span><input inputMode="decimal" value={form.rating} onChange={(event) => setForm({ ...form, rating: event.target.value })} placeholder="5.0" /></label>
          <label className="paField"><span>현재 페이지</span><input inputMode="numeric" value={form.currentPage} onChange={(event) => setForm({ ...form, currentPage: event.target.value })} placeholder="0" /></label>
          <label className="paField"><span>전체 페이지</span><input inputMode="numeric" value={form.totalPages} onChange={(event) => setForm({ ...form, totalPages: event.target.value })} placeholder="320" /></label>
          <div className="paField full"><span>상태</span><div className="paSegmented">{BOOK_STATUS.map((status) => <button type="button" key={status.value} className={form.status === status.value ? 'active' : ''} onClick={() => setForm({ ...form, status: status.value })}>{status.label}</button>)}</div></div>
          <label className="paField full"><span>메모</span><textarea value={form.memo} onChange={(event) => setForm({ ...form, memo: event.target.value })} placeholder="인상 깊은 문장, 구매처, 다음 독서 목표" rows={3} /></label>
          <button type="submit" className="paPrimary full" disabled={!form.title.trim()}>책 저장</button>
        </form>
      </SectionCard>

      <SectionCard>
        <SectionTitle eyebrow="Library" title="책장" value={`${filteredBooks.length}권`} />
        <div className="paFilterPills">
          <button type="button" className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>전체 {books.length}</button>
          {BOOK_STATUS.map((status) => <button type="button" key={status.value} className={filter === status.value ? 'active' : ''} onClick={() => setFilter(status.value)}>{status.label} {counts[status.value]}</button>)}
        </div>
        {filteredBooks.length ? (
          <div className="paList">
            {filteredBooks.map((book) => (
              <article className="paListItem book" key={book.id}>
                <div className="paListBody">
                  <div className="paListTitle"><strong>{book.title}</strong><b className={`paStatus ${book.status}`}>{BOOK_STATUS_MAP[book.status]}</b></div>
                  <span>{book.author || '작가 미입력'}{book.rating ? ` · ★ ${book.rating}` : ''}</span>
                  <MiniProgress value={getProgress(book)} />
                  {book.memo ? <p>{book.memo}</p> : null}
                </div>
                <div className="paListActions">
                  <select value={book.status} onChange={(event) => updateBook(book.id, { status: event.target.value })}>{BOOK_STATUS.map((status) => <option key={status.value} value={status.value}>{status.label}</option>)}</select>
                  <button type="button" onClick={() => setBooks(books.filter((item) => item.id !== book.id))} aria-label="삭제"><Icon name="trash" size={16} /></button>
                </div>
              </article>
            ))}
          </div>
        ) : <EmptyState title="책장이 비어 있어요" icon="book">제목만 입력해도 바로 책장에 추가됩니다.</EmptyState>}
      </SectionCard>
    </main>
  );
}

function WorkoutPage({ profile, setProfile, entries, setEntries, schedules, setSchedules }) {
  const [activeType, setActiveType] = useState('upper');
  const [date, setDate] = useState(getTodayString());
  const [startTime, setStartTime] = useState('');
  const [minutes, setMinutes] = useState('');
  const [scheduler, setScheduler] = useState(true);
  const [rows, setRows] = useState(() => EXERCISE_PRESETS.upper.map((item) => ({ ...item })));
  const activeMeta = WORKOUT_TABS.find((tab) => tab.value === activeType) || WORKOUT_TABS[0];
  const bmr = useMemo(() => {
    const weight = Number(profile.weight);
    const height = Number(profile.height);
    const age = Number(profile.age);
    if (!weight || !height || !age) return 0;
    const base = 10 * weight + 6.25 * height - 5 * age;
    return Math.round(profile.gender === 'female' ? base - 161 : base + 5);
  }, [profile]);
  const estimateKcal = useMemo(() => {
    const weight = Number(profile.weight);
    const duration = Number(minutes);
    if (!weight || !duration) return 0;
    return Math.round((activeMeta.met * 3.5 * weight * duration) / 200);
  }, [activeMeta.met, minutes, profile.weight]);
  const totalMinutes = entries.reduce((sum, entry) => sum + Number(entry.minutes || 0), 0);
  const totalKcal = entries.reduce((sum, entry) => sum + Number(entry.kcal || 0), 0);
  const todayDone = entries.some((entry) => entry.date === getTodayString());

  const switchType = (type) => {
    setActiveType(type);
    setRows(EXERCISE_PRESETS[type].map((item) => ({ ...item })));
  };
  const updateRow = (index, key, value) => setRows(rows.map((row, rowIndex) => rowIndex === index ? { ...row, [key]: value } : row));
  const saveWorkout = () => {
    const cleanRows = rows.filter((row) => row.name.trim()).map((row) => ({ ...row, name: row.name.trim() }));
    if (!cleanRows.length && !minutes) return;
    const id = uid();
    const newEntry = { id, type: activeType, label: activeMeta.label, date, startTime, minutes: Number(minutes || 0), kcal: estimateKcal, scheduler, rows: cleanRows, createdAt: new Date().toISOString() };
    setEntries([newEntry, ...entries]);
    if (scheduler) {
      setSchedules([{ id: `workout-${id}`, title: `${activeMeta.label} 운동`, date, time: startTime, category: 'workout', memo: cleanRows.map((row) => row.name).join(', '), done: false, source: 'workout' }, ...schedules]);
    }
    setMinutes('');
  };

  return (
    <main className="paContent">
      <section className="paCoachHero orange">
        <span><Icon name="trophy" size={21} /> 운동 코치</span>
        <h1>{todayDone ? '오늘 운동 기록 완료' : '오늘은 짧게라도 움직여볼까요?'}</h1>
        <p>{bmr ? `현재 BMR은 약 ${bmr} kcal입니다. 운동 시간을 넣으면 예상 소모 kcal를 계산합니다.` : '키, 몸무게, 나이를 입력하면 기초대사량과 운동 소모량이 더 앱답게 계산됩니다.'}</p>
      </section>

      <div className="paMetricGrid four">
        <MetricTile label="운동일" value={`${new Set(entries.map((entry) => entry.date)).size}일`} icon="calendar" tone="mint" />
        <MetricTile label="누적 시간" value={`${totalMinutes}분`} icon="clock" tone="orange" />
        <MetricTile label="기록 종목" value={`${entries.reduce((sum, entry) => sum + entry.rows.length, 0)}개`} icon="target" tone="blue" />
        <MetricTile label="소모" value={`${totalKcal}kcal`} icon="zap" tone="purple" />
      </div>

      <SectionCard>
        <SectionTitle eyebrow="Body profile" title="내 몸 정보" value={bmr ? `${bmr} kcal` : 'BMR -'} />
        <div className="paForm compact">
          <label className="paField"><span>몸무게(kg)</span><input inputMode="decimal" value={profile.weight} onChange={(event) => setProfile({ ...profile, weight: event.target.value })} placeholder="kg" /></label>
          <label className="paField"><span>키(cm)</span><input inputMode="decimal" value={profile.height} onChange={(event) => setProfile({ ...profile, height: event.target.value })} placeholder="cm" /></label>
          <label className="paField"><span>나이</span><input inputMode="numeric" value={profile.age} onChange={(event) => setProfile({ ...profile, age: event.target.value })} placeholder="30" /></label>
          <label className="paField"><span>성별</span><select value={profile.gender} onChange={(event) => setProfile({ ...profile, gender: event.target.value })}><option value="male">남성</option><option value="female">여성</option></select></label>
        </div>
      </SectionCard>

      <SectionCard>
        <SectionTitle eyebrow="Workout log" title="운동 기록" value={estimateKcal ? `${estimateKcal} kcal` : '자동 계산'} />
        <div className="paSegmented iconTabs">{WORKOUT_TABS.map((tab) => <button type="button" key={tab.value} className={activeType === tab.value ? 'active' : ''} onClick={() => switchType(tab.value)}><Icon name={tab.icon} size={17} />{tab.label}</button>)}</div>
        <div className="paForm compact">
          <label className="paField"><span>날짜</span><input type="date" value={date} onChange={(event) => setDate(event.target.value)} /></label>
          <label className="paField"><span>시작 시간</span><input type="time" value={startTime} onChange={(event) => setStartTime(event.target.value)} /></label>
          <label className="paField"><span>운동 시간(분)</span><input inputMode="numeric" value={minutes} onChange={(event) => setMinutes(event.target.value)} placeholder="30" /></label>
          <label className="paField"><span>예상 소모</span><input readOnly value={estimateKcal ? `${estimateKcal} kcal` : '체중/시간 입력'} /></label>
        </div>
        <button type="button" className={`paSwitch ${scheduler ? 'active' : ''}`} onClick={() => setScheduler(!scheduler)}><span><strong>일정에도 등록</strong><em>운동 저장 시 일정에 함께 표시합니다.</em></span><b>{scheduler ? 'ON' : 'OFF'}</b></button>
        <div className="paExerciseTable">
          <div className="paExerciseHead"><span>운동명</span><span>세트</span><span>횟수/분</span><span>kg</span><span /></div>
          {rows.map((row, index) => (
            <div className="paExerciseRow" key={`${activeType}-${index}`}>
              <input value={row.name} onChange={(event) => updateRow(index, 'name', event.target.value)} placeholder="운동명" />
              <input inputMode="numeric" value={row.sets} onChange={(event) => updateRow(index, 'sets', event.target.value)} placeholder="3" />
              <input inputMode="numeric" value={row.reps} onChange={(event) => updateRow(index, 'reps', event.target.value)} placeholder="10" />
              <input inputMode="decimal" value={row.weight} onChange={(event) => updateRow(index, 'weight', event.target.value)} placeholder="-" />
              <button type="button" onClick={() => setRows(rows.filter((_, rowIndex) => rowIndex !== index))} aria-label="행 삭제"><Icon name="trash" size={15} /></button>
            </div>
          ))}
        </div>
        <div className="paButtonRow"><button type="button" className="paGhost" onClick={() => setRows([...rows, { name: '', sets: '3', reps: '10', weight: '' }])}><Icon name="plus" size={16} /> 종목 추가</button><button type="button" className="paPrimary" onClick={saveWorkout}>기록 저장</button></div>
      </SectionCard>

      <SectionCard>
        <SectionTitle eyebrow="History" title="최근 운동" value={`${entries.length}개`} />
        {entries.length ? <div className="paList">{entries.slice(0, 8).map((entry) => <article className="paListItem" key={entry.id}><span className="paListIcon orange"><Icon name="trophy" size={17} /></span><div className="paListBody"><strong>{entry.label} · {entry.minutes || 0}분</strong><span>{formatDateKorean(entry.date)} {entry.startTime || '시간 미정'} · {entry.kcal || 0} kcal</span><p>{entry.rows.map((row) => row.name).join(', ') || '시간 기록'}</p></div><button type="button" onClick={() => setEntries(entries.filter((item) => item.id !== entry.id))} aria-label="삭제"><Icon name="trash" size={16} /></button></article>)}</div> : <EmptyState title="첫 운동을 저장해보세요" icon="trophy">시간을 입력하면 예상 칼로리가 자동 계산됩니다.</EmptyState>}
      </SectionCard>
    </main>
  );
}

function MemoPage({ memos, setMemos }) {
  const [text, setText] = useState('');
  const [tag, setTag] = useState('일반');
  const [query, setQuery] = useState('');
  const addMemo = () => {
    if (!text.trim()) return;
    setMemos([{ id: uid(), text: text.trim(), tag: tag.trim() || '일반', pinned: false, createdAt: new Date().toISOString() }, ...memos]);
    setText('');
  };
  const tags = Array.from(new Set(['전체', '비서', '일반', ...memos.map((memo) => memo.tag || '일반')])).slice(0, 10);
  const [tagFilter, setTagFilter] = useState('전체');
  const filtered = memos
    .filter((memo) => tagFilter === '전체' || (memo.tag || '일반') === tagFilter)
    .filter((memo) => !query.trim() || `${memo.text} ${memo.tag}`.toLowerCase().includes(query.trim().toLowerCase()))
    .sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || new Date(b.createdAt) - new Date(a.createdAt));

  return (
    <main className="paContent">
      <section className="paCoachHero mint"><span><Icon name="memo" size={21} /> 메모 비서</span><h1>흩어진 생각을 검색 가능한 기록으로.</h1><p>태그와 고정 기능으로 중요한 메모를 위로 올려두고, 필요할 때 빠르게 찾습니다.</p></section>
      <SectionCard>
        <SectionTitle eyebrow="Quick memo" title="새 메모" value={`${memos.length}개`} />
        <label className="paField full"><span>내용</span><textarea value={text} onChange={(event) => setText(event.target.value)} rows={5} placeholder="생각나는 것을 바로 적어두세요" /></label>
        <div className="paForm compact oneLine"><label className="paField"><span>태그</span><input value={tag} onChange={(event) => setTag(event.target.value)} placeholder="일반" /></label><button type="button" className="paPrimary alignBottom" onClick={addMemo} disabled={!text.trim()}>저장</button></div>
      </SectionCard>
      <SectionCard>
        <SectionTitle eyebrow="Saved notes" title="저장된 메모" value={`${filtered.length}개`} />
        <label className="paSearch"><Icon name="search" size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="메모 검색" /></label>
        <div className="paFilterPills">{tags.map((item) => <button type="button" key={item} className={tagFilter === item ? 'active' : ''} onClick={() => setTagFilter(item)}>{item}</button>)}</div>
        {filtered.length ? <div className="paList">{filtered.map((memo) => <article className={`paListItem memo ${memo.pinned ? 'pinned' : ''}`} key={memo.id}><div className="paListBody"><div className="paListTitle"><strong>{memo.text}</strong><b className="paStatus">#{memo.tag || '일반'}</b></div><span>{new Date(memo.createdAt).toLocaleString('ko-KR')}</span></div><div className="paListActions"><button type="button" onClick={() => setMemos(memos.map((item) => item.id === memo.id ? { ...item, pinned: !item.pinned } : item))} aria-label="고정"><Icon name="pin" size={16} /></button><button type="button" onClick={() => setMemos(memos.filter((item) => item.id !== memo.id))} aria-label="삭제"><Icon name="trash" size={16} /></button></div></article>)}</div> : <EmptyState title="메모가 없습니다" icon="memo">검색어를 지우거나 첫 메모를 남겨보세요.</EmptyState>}
      </SectionCard>
    </main>
  );
}

function SchedulePage({ schedules, setSchedules }) {
  const [form, setForm] = useState({ title: '', date: getTodayString(), time: '', category: 'personal', memo: '' });
  const addSchedule = (event) => {
    event.preventDefault();
    if (!form.title.trim()) return;
    setSchedules([{ id: uid(), ...form, title: form.title.trim(), memo: form.memo.trim(), done: false, createdAt: new Date().toISOString() }, ...schedules]);
    setForm({ title: '', date: getTodayString(), time: '', category: 'personal', memo: '' });
  };
  const toggleDone = (id) => setSchedules(schedules.map((item) => item.id === id ? { ...item, done: !item.done } : item));
  const today = getTodayString();
  const todayItems = schedules.filter((item) => item.date === today).sort((a, b) => `${a.time || '99:99'}`.localeCompare(`${b.time || '99:99'}`));
  const upcomingItems = schedules.filter((item) => item.date > today && !item.done).sort((a, b) => `${a.date} ${a.time || '99:99'}`.localeCompare(`${b.date} ${b.time || '99:99'}`));
  const overdueItems = schedules.filter((item) => item.date < today && !item.done).sort((a, b) => a.date.localeCompare(b.date));
  const doneItems = schedules.filter((item) => item.done).slice(0, 6);

  const ScheduleList = ({ items, empty }) => items.length ? <div className="paList">{items.map((item) => <article className={`paListItem schedule ${item.done ? 'done' : ''}`} key={item.id}><button type="button" className="paCheck" onClick={() => toggleDone(item.id)} aria-label="완료 변경"><Icon name="check" size={15} /></button><div className="paListBody"><strong>{item.title}</strong><span>{formatDateKorean(item.date)} {item.time || '종일'} · {statusLabel(SCHEDULE_CATEGORIES, item.category || 'personal')}</span>{item.memo ? <p>{item.memo}</p> : null}</div><button type="button" onClick={() => setSchedules(schedules.filter((entry) => entry.id !== item.id))} aria-label="삭제"><Icon name="trash" size={16} /></button></article>)}</div> : <EmptyState title={empty} icon="calendar">일정을 추가하면 비서 브리핑에 바로 반영됩니다.</EmptyState>;

  return (
    <main className="paContent">
      <section className="paCoachHero blue"><span><Icon name="calendar" size={21} /> 일정 비서</span><h1>{todayItems.filter((item) => !item.done).length ? `오늘 남은 일정 ${todayItems.filter((item) => !item.done).length}개` : '오늘 일정은 정리됐어요.'}</h1><p>{overdueItems.length ? `놓친 일정 ${overdueItems.length}개를 먼저 확인하세요.` : '오늘, 예정, 완료를 분리해서 할 일을 빠르게 정리합니다.'}</p></section>
      <div className="paMetricGrid three"><MetricTile label="오늘" value={`${todayItems.filter((item) => !item.done).length}개`} icon="calendar" tone="mint" /><MetricTile label="예정" value={`${upcomingItems.length}개`} icon="clock" tone="blue" /><MetricTile label="놓침" value={`${overdueItems.length}개`} icon="bell" tone="orange" /></div>
      <SectionCard>
        <SectionTitle eyebrow="New schedule" title="일정 추가" />
        <form className="paForm" onSubmit={addSchedule}>
          <label className="paField full"><span>일정명</span><input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="예: 병원 예약" /></label>
          <label className="paField"><span>날짜</span><input type="date" value={form.date} onChange={(event) => setForm({ ...form, date: event.target.value })} /></label>
          <label className="paField"><span>시간</span><input type="time" value={form.time} onChange={(event) => setForm({ ...form, time: event.target.value })} /></label>
          <label className="paField"><span>분류</span><select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>{SCHEDULE_CATEGORIES.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
          <label className="paField"><span>메모</span><input value={form.memo} onChange={(event) => setForm({ ...form, memo: event.target.value })} placeholder="장소, 준비물" /></label>
          <button type="submit" className="paPrimary full" disabled={!form.title.trim()}>일정 저장</button>
        </form>
      </SectionCard>
      {overdueItems.length ? <SectionCard className="dangerSurface"><SectionTitle eyebrow="Overdue" title="놓친 일정" value={`${overdueItems.length}개`} /><ScheduleList items={overdueItems} empty="놓친 일정이 없습니다" /></SectionCard> : null}
      <SectionCard><SectionTitle eyebrow="Today" title="오늘" value={`${todayItems.length}개`} /><ScheduleList items={todayItems} empty="오늘 일정이 없습니다" /></SectionCard>
      <SectionCard><SectionTitle eyebrow="Upcoming" title="다가오는 일정" value={`${upcomingItems.length}개`} /><ScheduleList items={upcomingItems} empty="예정된 일정이 없습니다" /></SectionCard>
      {doneItems.length ? <SectionCard><SectionTitle eyebrow="Done" title="최근 완료" value={`${doneItems.length}개`} /><ScheduleList items={doneItems} empty="완료 일정이 없습니다" /></SectionCard> : null}
    </main>
  );
}

function TravelPage({ trips, setTrips }) {
  const [form, setForm] = useState({ title: '', destination: '', startDate: getTodayString(), endDate: getTodayString(), status: 'planned', memo: '' });
  const today = getTodayString();
  const nextTrip = trips.filter((trip) => trip.startDate >= today && trip.status !== 'done').sort((a, b) => a.startDate.localeCompare(b.startDate))[0];
  const addTrip = (event) => {
    event.preventDefault();
    if (!form.title.trim()) return;
    setTrips([{ id: uid(), ...form, title: form.title.trim(), destination: form.destination.trim(), memo: form.memo.trim(), createdAt: new Date().toISOString() }, ...trips]);
    setForm({ title: '', destination: '', startDate: getTodayString(), endDate: getTodayString(), status: 'planned', memo: '' });
  };
  const updateTrip = (id, patch) => setTrips(trips.map((trip) => trip.id === id ? { ...trip, ...patch } : trip));
  const addChecklist = (text) => setForm({ ...form, memo: form.memo ? `${form.memo}, ${text}` : text });

  return (
    <main className="paContent">
      <section className="paCoachHero green"><span><Icon name="map" size={21} /> 여행 컨시어지</span><h1>{nextTrip ? `${nextTrip.title} D-${Math.max(0, getDayDiff(nextTrip.startDate) || 0)}` : '다음 여행을 준비해볼까요?'}</h1><p>{nextTrip ? `${nextTrip.destination || '목적지 미정'} · ${formatDateCompact(nextTrip.startDate)} 출발입니다.` : '여행 이름, 일정, 예약 상태, 준비물을 한 카드에 모아둡니다.'}</p></section>
      <div className="paMetricGrid three"><MetricTile label="예정" value={`${trips.filter((trip) => trip.startDate >= today && trip.status !== 'done').length}개`} icon="map" tone="mint" /><MetricTile label="예약" value={`${trips.filter((trip) => trip.status === 'booked').length}개`} icon="shield" tone="blue" /><MetricTile label="완료" value={`${trips.filter((trip) => trip.status === 'done').length}개`} icon="check" tone="purple" /></div>
      <SectionCard>
        <SectionTitle eyebrow="Trip planner" title="여행 추가" />
        <form className="paForm" onSubmit={addTrip}>
          <label className="paField full"><span>여행 이름</span><input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="예: 부산 주말 여행" /></label>
          <label className="paField full"><span>목적지</span><input value={form.destination} onChange={(event) => setForm({ ...form, destination: event.target.value })} placeholder="부산, 제주, 도쿄" /></label>
          <label className="paField"><span>출발</span><input type="date" value={form.startDate} onChange={(event) => setForm({ ...form, startDate: event.target.value })} /></label>
          <label className="paField"><span>도착</span><input type="date" value={form.endDate} onChange={(event) => setForm({ ...form, endDate: event.target.value })} /></label>
          <label className="paField"><span>상태</span><select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}>{TRIP_STATUS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
          <label className="paField"><span>메모</span><input value={form.memo} onChange={(event) => setForm({ ...form, memo: event.target.value })} placeholder="숙소, 준비물, 예산" /></label>
          <div className="paAssistChips full"><span>준비물 추천</span>{['신분증', '충전기', '예약번호', '우산'].map((item) => <button type="button" key={item} onClick={() => addChecklist(item)}>{item}</button>)}</div>
          <button type="submit" className="paPrimary full" disabled={!form.title.trim()}>여행 저장</button>
        </form>
      </SectionCard>
      <SectionCard><SectionTitle eyebrow="Trips" title="여행 목록" value={`${trips.length}개`} />{trips.length ? <div className="paList">{trips.map((trip) => <article className="paListItem trip" key={trip.id}><span className="paListIcon green"><Icon name="map" size={17} /></span><div className="paListBody"><div className="paListTitle"><strong>{trip.title}</strong><b className={`paStatus ${trip.status}`}>{statusLabel(TRIP_STATUS, trip.status)}</b></div><span>{trip.destination || '목적지 미정'} · {formatDateCompact(trip.startDate)}~{formatDateCompact(trip.endDate)} · {getDaysBetween(trip.startDate, trip.endDate)}일</span>{trip.memo ? <p>{trip.memo}</p> : null}</div><div className="paListActions"><select value={trip.status} onChange={(event) => updateTrip(trip.id, { status: event.target.value })}>{TRIP_STATUS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select><button type="button" onClick={() => setTrips(trips.filter((item) => item.id !== trip.id))} aria-label="삭제"><Icon name="trash" size={16} /></button></div></article>)}</div> : <EmptyState title="저장된 여행이 없습니다" icon="map">다가오는 여행을 카드로 관리해보세요.</EmptyState>}</SectionCard>
    </main>
  );
}

function FinancePage({ transactions, setTransactions, budget, setBudget }) {
  const [form, setForm] = useState({ type: 'expense', amount: '', category: '식비', date: getTodayString(), memo: '' });
  const totals = getMonthTotals(transactions);
  const categoryRows = getExpenseByCategory(transactions);
  const monthlyBudget = Number(budget.monthly || 0);
  const budgetRate = monthlyBudget ? clamp(Math.round((totals.expense / monthlyBudget) * 100)) : 0;
  const addTransaction = (event) => {
    event.preventDefault();
    if (!Number(form.amount)) return;
    setTransactions([{ id: uid(), ...form, amount: Number(form.amount), memo: form.memo.trim(), createdAt: new Date().toISOString() }, ...transactions]);
    setForm({ ...form, amount: '', memo: '' });
  };
  return (
    <main className="paContent">
      <section className="paFinanceHero"><span className="paKicker">Finance assistant</span><h1>{formatCurrency(totals.balance)}</h1><p>이번 달 수입 {formatCurrency(totals.income)} · 지출 {formatCurrency(totals.expense)}</p><MiniProgress value={budgetRate} /><em>{monthlyBudget ? `예산 ${formatCurrency(monthlyBudget)} 중 ${budgetRate}% 사용` : '월 예산을 입력하면 사용률을 보여줍니다.'}</em></section>
      <div className="paMetricGrid three"><MetricTile label="수입" value={formatCurrency(totals.income)} icon="trend" tone="mint" /><MetricTile label="지출" value={formatCurrency(totals.expense)} icon="wallet" tone="orange" /><MetricTile label="기록" value={`${totals.count}건`} icon="memo" tone="blue" /></div>
      <SectionCard>
        <SectionTitle eyebrow="Budget" title="월 예산" />
        <div className="paForm compact oneLine"><label className="paField"><span>이번 달 예산</span><input inputMode="numeric" value={budget.monthly} onChange={(event) => setBudget({ ...budget, monthly: event.target.value })} placeholder="800000" /></label><div className="paBudgetMini"><strong>{budgetRate}%</strong><span>사용률</span></div></div>
      </SectionCard>
      <SectionCard>
        <SectionTitle eyebrow="Ledger" title="입출금 기록" />
        <form className="paForm" onSubmit={addTransaction}>
          <div className="paField full"><span>유형</span><div className="paSegmented"><button type="button" className={form.type === 'expense' ? 'active' : ''} onClick={() => setForm({ ...form, type: 'expense' })}>지출</button><button type="button" className={form.type === 'income' ? 'active' : ''} onClick={() => setForm({ ...form, type: 'income' })}>수입</button></div></div>
          <label className="paField"><span>금액</span><input inputMode="numeric" value={form.amount} onChange={(event) => setForm({ ...form, amount: event.target.value })} placeholder="12000" /></label>
          <label className="paField"><span>분류</span><select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>{FINANCE_CATEGORIES.map((category) => <option key={category} value={category}>{category}</option>)}</select></label>
          <label className="paField"><span>날짜</span><input type="date" value={form.date} onChange={(event) => setForm({ ...form, date: event.target.value })} /></label>
          <label className="paField"><span>메모</span><input value={form.memo} onChange={(event) => setForm({ ...form, memo: event.target.value })} placeholder="점심, 월급 등" /></label>
          <button type="submit" className="paPrimary full" disabled={!Number(form.amount)}>저장</button>
        </form>
      </SectionCard>
      {categoryRows.length ? <SectionCard><SectionTitle eyebrow="Spending" title="카테고리별 지출" /> <div className="paCategoryBars">{categoryRows.slice(0, 5).map(([name, amount]) => <div className="paCategoryBar" key={name}><div><strong>{name}</strong><span>{formatCurrency(amount)}</span></div><MiniProgress value={totals.expense ? Math.round((amount / totals.expense) * 100) : 0} /></div>)}</div></SectionCard> : null}
      <SectionCard><SectionTitle eyebrow="History" title="최근 입출금" value={`${transactions.length}건`} />{transactions.length ? <div className="paList">{transactions.map((item) => <article className={`paListItem finance ${item.type}`} key={item.id}><span className="paListIcon blue"><Icon name="wallet" size={17} /></span><div className="paListBody"><strong>{item.memo || item.category}</strong><span>{formatDateKorean(item.date)} · {item.category}</span></div><strong className="paMoney">{item.type === 'income' ? '+' : '-'}{formatCurrency(item.amount)}</strong><button type="button" onClick={() => setTransactions(transactions.filter((entry) => entry.id !== item.id))} aria-label="삭제"><Icon name="trash" size={16} /></button></article>)}</div> : <EmptyState title="입출금 기록이 없습니다" icon="wallet">첫 지출이나 수입을 저장해보세요.</EmptyState>}</SectionCard>
    </main>
  );
}

export default function LifeHubApp({ path, navigate }) {
  const route = normalizePath(path);
  const [books, setBooks] = usePersistentState(STORAGE_KEYS.books, []);
  const [profile, setProfile] = usePersistentState(STORAGE_KEYS.workoutProfile, { weight: '', height: '', age: '30', gender: 'male' });
  const [workoutEntries, setWorkoutEntries] = usePersistentState(STORAGE_KEYS.workoutEntries, []);
  const [memos, setMemos] = usePersistentState(STORAGE_KEYS.memo, []);
  const [schedules, setSchedules] = usePersistentState(STORAGE_KEYS.schedules, []);
  const [trips, setTrips] = usePersistentState(STORAGE_KEYS.trips, []);
  const [transactions, setTransactions] = usePersistentState(STORAGE_KEYS.transactions, []);
  const [budget, setBudget] = usePersistentState(STORAGE_KEYS.budget, { monthly: '' });

  useEffect(() => {
    document.title = 'LifeHub Assistant';
  }, []);

  const data = { books, profile, workoutEntries, memos, schedules, trips, transactions, budget };
  const setters = { setBooks, setProfile, setWorkoutEntries, setMemos, setSchedules, setTrips, setTransactions, setBudget };
  const briefing = useMemo(() => buildAssistantBriefing(data), [books, profile, workoutEntries, memos, schedules, trips, transactions, budget]);

  let page;
  if (route === '/home') page = <HomePage data={data} setters={setters} briefing={briefing} navigate={navigate} />;
  else if (route === '/memo') page = <MemoPage memos={memos} setMemos={setMemos} />;
  else if (route === '/schedule') page = <SchedulePage schedules={schedules} setSchedules={setSchedules} />;
  else if (route === '/more') page = <MorePage data={data} setters={setters} navigate={navigate} />;
  else if (route === '/reading') page = <ReadingPage books={books} setBooks={setBooks} />;
  else if (route === '/workout') page = <WorkoutPage profile={profile} setProfile={setProfile} entries={workoutEntries} setEntries={setWorkoutEntries} schedules={schedules} setSchedules={setSchedules} />;
  else if (route === '/travel') page = <TravelPage trips={trips} setTrips={setTrips} />;
  else if (route === '/finance') page = <FinancePage transactions={transactions} setTransactions={setTransactions} budget={budget} setBudget={setBudget} />;
  else page = <HomePage data={data} setters={setters} briefing={briefing} navigate={navigate} />;

  return (
    <div className="lifeApp paApp">
      <div className="lifePhoneSurface paSurface">
        <AppHeader route={route} navigate={navigate} briefingCount={briefing.length} />
        {page}
        <BottomNav route={route} navigate={navigate} />
      </div>
    </div>
  );
}
