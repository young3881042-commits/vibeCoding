# LifeHub Assistant UI/UX Refresh

이번 버전은 기존 생활 관리 화면을 단순 기록장이 아니라 개인비서형 모바일 앱처럼 보이도록 재구성했습니다.

## 핵심 변경

- 홈을 `오늘의 비서` 대시보드로 변경
  - 시간대별 인사
  - 오늘 일정, 운동, 독서, 월 잔액 요약
  - 지금 확인해야 할 항목을 자동 브리핑 카드로 노출
- 로컬 규칙 기반 `비서 브리핑` 추가
  - 놓친 일정
  - 오늘 일정
  - 운동 미기록 / 운동 완료
  - 읽던 책 이어보기
  - 여행 D-day
  - 예산 사용률 / 현금 흐름
  - 고정 메모
- `비서에게 맡기기` 빠른 입력 추가
  - “내일 병원 예약 확인”처럼 입력하면 일정으로 저장
  - 메모 모드로 바꾸면 메모로 저장
- 더보기 화면을 `관리 센터`로 변경
  - 기능 카드에 현재 상태 수치 노출
  - 아침 브리핑, 저녁 정리, 주간 점검 루틴 빠른 등록
- 각 모듈을 비서형 톤으로 재구성
  - 독서 코치
  - 운동 코치
  - 일정 비서
  - 여행 컨시어지
  - 재무 비서
  - 메모 비서
- 가계부에 월 예산과 카테고리별 지출 바 추가
- 여행 화면에 준비물 추천 칩 추가
- 전체 스타일을 모바일 앱 중심으로 재정리
  - 상단 glass header
  - assistant status pill
  - bottom tab bar
  - card hierarchy
  - softer spacing, touch targets, focused empty states

## 수정 파일

```text
apps/web/src/LifeHubApp.jsx
apps/web/src/styles.css
ASSISTANT_UI_CHANGES.md
```

## 실행

```bash
cd apps/web
npm ci
npm run dev -- --host 0.0.0.0
```

## 확인 경로

```text
/home
/memo
/schedule
/more
/reading
/workout
/travel
/finance
```

## 빌드 확인

```bash
cd apps/web
npm run build
```

빌드는 성공했습니다. 기존 CodeEditor 청크 크기 경고는 기존 코드 에디터 번들에서 발생하는 Vite 경고이며, LifeHub Assistant UI 오류는 아닙니다.
